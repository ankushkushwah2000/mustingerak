<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class frontendController extends Controller
{
   public function index(){
       $data = Category::all();
       $product = Product::where("status",1)->get();
       return view('frontend.index',compact('data','product'));
   }

   public function track_order(){
       return view('frontend.truckorder');
   }

   public function about(){
       return view('frontend.about');
   }

   public function contact(){
       return view('frontend.contact');
   }
   public function singal_product($id){
       $data = Product::where("id",$id)->get();
       return view('frontend.singal_product',compact('data'));
   }
   public function add_to_cart(Request $a){
       $data = new Cart();
       $data->product_id=$a->product_id;
       $data->quantity=$a->quantity;
       $data->discount=1;
       $data->user_id= Auth::user()->id;
       $data->save();
       return redirect('/cart');
   }
   public function cart(){
       $user_id= Auth::user()->id;
       $data = Cart::where("user_id",$user_id)->get();
       return view('frontend.partition.cart',compact('data'));
   }
}
